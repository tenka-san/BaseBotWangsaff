require('../config/settings');
const { 
    default: makeWASocket, 
    prepareWAMessageMedia, 
    useMultiFileAuthState, 
    DisconnectReason, 
    fetchLatestBaileysVersion, 
    makeInMemoryStore, 
    generateWAMessageFromContent, 
    generateWAMessageContent, 
    jidDecode, 
    proto, 
    relayWAMessage, 
    getContentType, 
    getAggregateVotesInPollMessage, 
    downloadContentFromMessage, 
    fetchLatestWaWebVersion, 
    InteractiveMessage, 
    makeCacheableSignalKeyStore, 
    Browsers, 
    generateForwardMessageContent, 
    MessageRetryMap 
} = require("@whiskeysockets/baileys");
const axios = require('axios');
const pino = require('pino');
const fs = require('fs');
const path = require('path');
const figlet = require('figlet');
const chalk = require("chalk");
const crypto = require('crypto');
const { Boom } = require('@hapi/boom');
const { color } = require('../lib/color');
const { createInterface } = require('readline');
const { smsg, sendGmail, formatSize, isUrl, generateMessageTag, getBuffer, getSizeMedia, runtime, fetchJson, sleep } = require('../lib/myfunc');

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

let usePairingCode = true;

console.clear()
console.log(chalk.white.bold(`
${chalk.blue("█░▄▀ █ █░░ █░░ █▀ █▀▀▄\n█▀▄░ █ █░░ █░░ █▀ █▐█▀\n▀░▀▀ ▀ ▀▀▀ ▀▀▀ ▀▀ ▀░▀▀\n▄▀█ █░█ █▀ █▀ █▄░█\n█▄█ █░█ █▀ █▀ █░▀█\n░░▀ ▀▀▀ ▀▀ ▀▀ ▀░░▀")}
`));  
console.log(chalk.white.bold(`${chalk.cyan(`Kiler Queen Version Seven`)}

`));

// Whatsapp Connect
async function ConnetToWhatsapp() {
    const { state, saveCreds } = await useMultiFileAuthState(`./${global.session}`);

    const Yuukey = makeWASocket({
        logger: pino({ level: "silent" }),
        printQRInTerminal: !usePairingCode,
        auth: state,
        browser: ["Ubuntu", "Chrome", "20.0.04"]
    });

    if (usePairingCode && !Yuukey.authState.creds.registered) {
        try {
            console.log(chalk.hex("#800080").bold("Enter Your Number Starts With 628, Dont Use + - Or Space\nUr Number : "));

            const phoneNumber = await question("");

            if (!phoneNumber?.trim()) {
                console.log(chalk.red("Invalid number. Please try again."));
                return;
            }

            let code = await Yuukey.requestPairingCode(phoneNumber.trim());
            code = code.match(/.{1,4}/g)?.join(" - ") || code;

            console.log(chalk.hex("#800080").bold("Your Pairing Code :"), chalk.yellow.bold(code));
        } catch (error) {
            console.log(chalk.red("An error occurred while processing the number: " + error.message));
        }
    }
  
// Create an in-memory store
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });
    store.bind(Yuukey.ev);
  
Yuukey.ev.on("messages.upsert", async (chatUpdate, msg) => {
 try {
const mek = chatUpdate.messages[0]
if (!mek.message) return
mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
if (mek.key && mek.key.remoteJid === 'status@broadcast') return
if (!Yuukey.public && !mek.key.fromMe && chatUpdate.type === 'notify') return
if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return
if (mek.key.id.startsWith('FatihArridho_')) return;
const m = smsg(Yuukey, mek, store)
require("../Start/Queen")(Yuukey, m, chatUpdate, store)
 } catch (err) {
 console.log(err)
 }
});

    Yuukey.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && decode.user + '@' + decode.server || jid;
        } else return jid;
    };

    Yuukey.ev.on('contacts.update', update => {
        for (let contact of update) {
            let id = Yuukey.decodeJid(contact.id);
            if (store && store.contacts) store.contacts[id] = { id, name: contact.notify };
        }
    });
    
    global.idch1 = "120363399602691477@newsletter"
    global.idch2 = "120363418309715113@newsletter"
    Yuukey.public = true

    Yuukey.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            const reason = new Boom(lastDisconnect?.error)?.output.statusCode;
            console.log(color(lastDisconnect.error, 'deeppink'));
            if (lastDisconnect.error == 'Error: Stream Errored (unknown)') {
                process.exit();
            } else if (reason === DisconnectReason.badSession) {
                console.log(color(`Bad Session File, Please Delete Session and Scan Again`));
                process.exit();
            } else if (reason === DisconnectReason.connectionClosed) {
                console.log(color('[SYSTEM]', 'white'), color('Connection closed, reconnecting...', 'deeppink'));
                process.exit();
            } else if (reason === DisconnectReason.connectionLost) {
                console.log(color('[SYSTEM]', 'white'), color('Connection lost, trying to reconnect', 'deeppink'));
                process.exit();
            } else if (reason === DisconnectReason.connectionReplaced) {
                console.log(color('Connection Replaced, Another New Session Opened, Please Close Current Session First'));
                Yuukey.logout();
            } else if (reason === DisconnectReason.loggedOut) {
                console.log(color(`Device Logged Out, Please Scan Again And Run.`));
                Yuukey.logout();
            } else if (reason === DisconnectReason.restartRequired) {
                console.log(color('Restart Required, Restarting...'));
                await ConnetToWhatsapp();
            } else if (reason === DisconnectReason.timedOut) {
                console.log(color('Connection TimedOut, Reconnecting...'));
                ConnetToWhatsapp();
            }
        } else if (connection === "connecting") {
            console.log(color('Menghubungkan . . . '));
        } else if (connection === "open") {
            console.log(color('Bot Berhasil Tersambung'));
    Yuukey.sendMessage("6285943212106@s.whatsapp.net", {
    text: `𝐊𝐢𝐥𝐥𝐞𝐫 𝐐𝐮𝐞𝐞𝐧 𝐕𝟕 𝐇𝐚𝐬 𝐂𝐨𝐧𝐧𝐞𝐜𝐭𝐞𝐝 𝐈𝐧 𝐌𝐲 𝐍𝐮𝐦𝐛𝐞𝐫\n𝐏𝐥𝐞𝐚𝐬𝐞 𝐒𝐮𝐛𝐬𝐜𝐫𝐢𝐛𝐞 𝐌𝐲 𝐘𝐨𝐮𝐭𝐮𝐛𝐞 𝐂𝐡𝐚𝐧𝐧𝐞𝐥 :\nhttps://Youtube.com/@YuukeyMiAyam`
    })
            Yuukey.newsletterFollow(global.idch1)
            Yuukey.newsletterFollow(global.idch2) 
            sendTelegramNotification(`Connection information report 🔥\n\nThe device has been connected, Here is the information\n> User ID : ${Yuukey.user.id}\n> Username : ${Yuukey.user.name}\n\nKiller Queen : Created By Yuukey Developer`);
        }
    });

    Yuukey.sendText = (jid, text, quoted = '', options) => Yuukey.sendMessage(jid, { text: text, ...options }, { quoted });
    
    Yuukey.downloadMediaMessage = async (message) => {
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(message, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])}
return buffer
    } 
    
    Yuukey.ev.on('creds.update', saveCreds);
    return Yuukey;
}

ConnetToWhatsapp();

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
    require('fs').unwatchFile(file);
    console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
    delete require.cache[file];
    require(file);
});
